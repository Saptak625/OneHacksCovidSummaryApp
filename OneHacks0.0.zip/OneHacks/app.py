from flask import Flask, redirect, request, url_for, render_template, abort, session, flash
from socialStats import getSocialStats

# Flask app setup
app = Flask(__name__)
# app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(24)
app.config['SECRET_KEY'] = '7b7e30111ddc1f8a5b1d80934d336798'

@app.route("/")
@app.route("/homepage")
def home():
    return render_template('homepage.html')

@app.route("/news")
def news():
    return render_template('news.html')

@app.route("/covidstats")
def covidStats():
    return render_template('covidstats.html')

@app.route("/socialstats")
def socialStats():
    getSocialStats()
    return render_template('socialstats.html')

if __name__ == "__main__":
    #Development only
    app.run(debug=True)
    #Production only
    # app.run(host = '0.0.0.0', ssl_context="adhoc")